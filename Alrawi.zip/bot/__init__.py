users ={} 
user_time = {} 